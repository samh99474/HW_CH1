package test;

public class p31 {
	public static void main(String[] args)
	{	
		
		System.out.println("1+2����"+(1+2));
		System.out.println("3*4����"+(3*4));
		int num1=2;
		int num2=3;
		int sum = num1 + num2;
		
		System.out.println("num1�Ȭ�"+num1);
		System.out.println("num2�Ȭ�"+num2);
		System.out.println("num1+num2�Ȭ�"+sum);
		num1=num1 + 1;
		System.out.println("num1�[1�᪺�Ȭ�"+num1);
	}


}
