package test;

public class p18 {

	public static void main(String[] args)
	{	
	System.out.println("��ܥX�ϱ׽u:\\");
	System.out.println("��ܥX��޸�\'");
	
	}

}
