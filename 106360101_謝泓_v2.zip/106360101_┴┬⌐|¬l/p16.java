package test;

public class p16 {

	public static void main(String[] args)
	{	
	System.out.println('A');
	System.out.println("�w��ϥ�JAVA�a!");
	System.out.println(123);
	}

}
