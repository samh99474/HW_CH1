package test;

public class p26 {
	public static void main(String[] args)
	{	
		int num;
		num=3;
		System.out.println("num�Ȭ�"+num);
		System.out.println("��snum��");
		num=5;
		System.out.println("��s��num�Ȭ�"+num);
	}


}
