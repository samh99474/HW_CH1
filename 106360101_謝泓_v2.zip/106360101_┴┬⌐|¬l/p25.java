package test;

public class p25 {
	public static void main(String[] args)
	{	
		int num;
		num=3;
		System.out.println("num�Ȭ�"+num);
	}


}
