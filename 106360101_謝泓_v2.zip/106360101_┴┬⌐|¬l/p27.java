package test;

public class p27 {
	public static void main(String[] args)
	{	
		int num1,num2;
		num1=3;
		System.out.println("num1�Ȭ�"+num1);
		num2=num1;
		System.out.println("�Nnum1�ȫ��w��num2");
		System.out.println("num2�Ȭ�"+num2);
	}


}
